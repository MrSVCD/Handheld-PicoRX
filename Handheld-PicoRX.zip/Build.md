# Print and Build instructions

## Printing

Print 1 miniradio-

## Building

